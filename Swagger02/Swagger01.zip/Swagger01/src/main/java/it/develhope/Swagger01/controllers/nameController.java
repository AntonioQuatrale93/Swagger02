package it.develhope.Swagger01.controllers;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/name")
public class nameController {


@GetMapping(value = "")
@ApiOperation(value = "Say my name", notes = "print my name")
@ApiResponses({
@ApiResponse(code = 200, message = "Ok, I'll tell you my name"),
@ApiResponse(code = 400, message = "I forgot my name ")

})
    public String getMyName(){
        return "My name is Antonio";
    }



}
